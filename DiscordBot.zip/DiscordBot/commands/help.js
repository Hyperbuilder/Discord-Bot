module.exports = {
    name: 'help',
    description: "this will give you some Help",
    execute(message, args){
        const exampleEmbed = {color: 0x0099ff,
            title: 'Help',
            author: {
                name: 'Bot',
                icon_url: 'https://i.imgur.com/ApYQvjZ.png',
            },
            description: 'All The command i have in store.',
            fields: [
                {
                    name: '!Help',
                    value: 'Shows this message',
                },
                {
                    name: '\u200b',
                    value: '\u200b',
                    inline: false,
                },
                {
                    name: 'TestTest',
                    value: 'Test',
                    inline: true,
                },
            ],
            timestamp: new Date(),
            footer: {
                text: 'Made for the Create Technical Discord Server',
                icon_url: 'https://i.imgur.com/ApYQvjZ.png',
            },
        };

        if (message.author.bot) {
            exampleEmbed.setColor = ('0x0099ff');
        }
        message.channel.send({ embed: exampleEmbed });
    }    
}